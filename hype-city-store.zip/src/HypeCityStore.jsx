import React from 'react';

export default function HypeCityStore() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>HYPE CITY</h1>
      <p style={{ color: '#aaa', marginBottom: '2rem' }}>Roupa de Drip • Estilo de Verdade</p>
      <div style={{
        maxWidth: '400px',
        margin: '0 auto',
        padding: '1rem',
        backgroundColor: '#1a1a1a',
        borderRadius: '1rem',
        border: '1px solid #333'
      }}>
        <img src="/conjunto-preto.jpg" alt="Conjunto Drip" style={{ width: '100%', borderRadius: '0.75rem' }} />
        <h2 style={{ marginTop: '1rem' }}>Conjunto Preto HYPE CITY</h2>
        <p style={{ color: '#ccc' }}>Tecido premium, caimento perfeito.</p>
        <p style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>R$ 299,90</p>
        <button style={{
          marginTop: '1rem',
          padding: '0.75rem 1.5rem',
          backgroundColor: '#00ffff',
          border: 'none',
          borderRadius: '0.5rem',
          color: 'black',
          fontWeight: 'bold',
          cursor: 'pointer'
        }}>
          Comprar com Pix ou Cartão
        </button>
      </div>
    </div>
  );
}