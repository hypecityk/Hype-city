import React from 'react';
import ReactDOM from 'react-dom/client';
import HypeCityStore from './HypeCityStore';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <HypeCityStore />
  </React.StrictMode>
);